# Big Little Things Foundation — full-stack project

This zip combines both halves of the application:

```
bltf-fullstack/
|-- frontend/     Static site (Lerato's repo) — HTML/CSS/vanilla JS
`-- backend/       Flask API (your build) — hours, PayFast, certificates
```

Both talk to the same Supabase project. See `backend/README.md` for full
backend setup (env vars, SQL, endpoints) and `BLTF_VSCode_Terminal_Setup.pdf`
(sent earlier) for the exact terminal commands to get the backend running.

## What's actually wired up right now

- **Donations (`frontend/donate.html`)** — fully connected. `submitDonation()`
  now calls `backend/routes/donations.py` for real, instead of writing to the
  localStorage demo DB. Money donations get redirected to PayFast with a
  properly signed payload; item donations are recorded directly. This was
  the piece we built and smoke-tested end to end.
- **Everything else in `frontend/`** — still running in the original
  localStorage demo mode (`public/js/config.js`'s `DB` helper). Volunteer
  hours, admin approvals, and certificate downloads have real backend
  endpoints ready in `backend/routes/hours.py` and `backend/routes/certificates.py`,
  but `dashboard/volunteer.html` and `dashboard/admin.html` haven't been
  rewired to call them yet — that's the natural next step.

## Quick start

1. **Backend**: `cd backend`, follow `backend/README.md` (venv, pip install,
   `.env`, run the two SQL files in Supabase, `python app.py`).
2. **Frontend**: `cd frontend`, serve it with anything static, e.g.
   `python3 -m http.server 5500`, then open `http://localhost:5500` in a
   browser.
3. Set `window.BLTF_API_BASE` in the frontend (or edit the `API_BASE`
   constant near the top of `donate.html`'s script) if your backend isn't
   running on `http://localhost:5000`.

## Combined-serving mode (no laptop needed — test from your phone)

`backend/app.py` now also serves the entire `frontend/` folder itself, as
long as `frontend/` sits next to `backend/` (exactly as it does in this
zip). That means **one running process handles everything** — no separate
frontend server, no CORS setup, no juggling two terminals. This was added
specifically to make phone-only testing realistic, since running two
processes side by side on a phone is painful.

### On your phone, using Replit (no laptop):

1. Go to replit.com in your phone's browser (or the Replit app) and sign in.
2. Create a new Repl → **Import from GitHub** (push this folder to a repo
   first) — or use Replit's file upload to bring in this zip directly.
3. Make sure `backend/` and `frontend/` stay as sibling folders inside the
   Repl (don't flatten them).
4. In Replit's **Secrets** tab (its env var manager — works fine on mobile),
   add: `SUPABASE_URL`, `SUPABASE_SERVICE_KEY`, `PAYFAST_MERCHANT_ID`,
   `PAYFAST_MERCHANT_KEY`, `PAYFAST_SANDBOX=true`, `SITE_URL`,
   `PAYFAST_NOTIFY_URL` (see `backend/.env.example` for the full list —
   Replit Secrets replace the `.env` file, don't use both).
5. Set the Repl's run command to: `cd backend && pip install -r requirements.txt && python app.py`
6. Open your Supabase project in the phone browser too (Supabase's SQL
   Editor and Storage pages both work on mobile) — paste and run
   `backend/sql/schema.sql`, then `backend/sql/donations.sql`, and create
   the private `certificates` Storage bucket.
7. Tap **Run**. Replit gives you a live public URL automatically — open it
   to see the actual site, click through to `/donate.html`, and test a
   donation. No ngrok needed either: Replit's public URL is already
   reachable from PayFast's servers, so set `PAYFAST_NOTIFY_URL` to that
   Replit URL.

This is the same reasoning covered earlier in this conversation: iSH's
Node.js is currently broken by a long-standing unresolved bug, and even for
the Python side, iSH's emulation makes pip installs unreliable. Replit runs
your actual code on a real server — your phone is just the remote control.

## Next step to fully connect it

Apply the same pattern used in `donate.html` to `dashboard/volunteer.html`
(hour submission, calling `POST /api/hours`) and `dashboard/admin.html`
(approve/reject buttons, calling the `/api/hours/<id>/approve` and `/reject`
endpoints, and listing certificates via `/api/certificates/<user_id>`).
Happy to do that wiring next.
